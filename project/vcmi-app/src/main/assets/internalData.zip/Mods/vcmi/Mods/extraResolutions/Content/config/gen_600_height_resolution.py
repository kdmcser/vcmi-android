import json

x = input("resolution width:")
while True:
	try:
		x = int(x)
		if x >= 600:
			break
	except:
		print("%s is not valid resolution width" % x)
		x = input("resolution width:")
		
		
elem = {
	"resolution": { "x": x, "y": 600 },
	"InGameConsole": { "maxInputPerLine": 60, "maxOutputPerLine": 39 },
	"AdvMap": { "x": 7, "y": 7, "width": x - 206, "height": 546, "smoothMove": 1, "puzzleSepia": 1 },
	"InfoBox": { "x": x - 195, "y": 389 },
	"gem0": { "x": 6, "y": 508, "graphic": "agemLL.def" },
	"gem1": { "x": x - 244, "y": 508, "graphic": "agemLR.def" },
	"gem2": { "x": 6, "y": 6, "graphic": "agemUL.def" },
	"gem3": { "x": x - 244, "y": 6, "graphic": "agemUR.def" },
	"background": "AdvMap%sx600.pcx" % x,
	"HeroList": { "size": 5, "x": x - 191, "y": 196, "movePoints": "IMOBIL.DEF", "manaPoints": "IMANA.DEF", "arrowUp": "IAM012.DEF", "arrowDown": "IAM013.DEF" },
	"TownList": { "size": 5, "x": x - 53, "y": 196, "arrowUp": "IAM014.DEF", "arrowDown": "IAM015.DEF" },
	"Minimap": { "width": 144, "height": 144, "x": x - 170, "y": 26 },
	"Overview": { "pics": 4, "size": 4, "graphic": "OvCast.pcx" },
	"Statusbar": { "x": 7, "y": 556, "graphic": "AdRollvr%s.pcx" % x },
	"ResDataBar": { "x": 3, "y": 575, "graphic": "ZResBar%s.pcx" % x, "offsetX": 32, "offsetY": 2, "resSpace": 85, "resDateSpace": 85 },
	"ButtonKingdomOv": { "x": x - 121, "y": 196, "graphic": "IAM002.DEF", "playerColoured": 1 },
	"ButtonUnderground": { "x": x - 89, "y": 196, "graphic": "IAM010.DEF", "playerColoured": 1, "additionalDefs": [ "IAM003.DEF" ] },
	"ButtonQuestLog": { "x": x - 121, "y": 228, "graphic": "IAM004.DEF", "playerColoured": 1 },
	"ButtonSleepWake": { "x": x - 89, "y": 228, "graphic": "IAM005.DEF", "playerColoured": 1, "additionalDefs":["IAM011.DEF"] },
	"ButtonMoveHero": { "x": x - 121, "y": 260, "graphic": "IAM006.DEF", "playerColoured": 1 },
	"ButtonSpellbook": { "x": x - 89, "y": 260, "graphic": "IAM007.DEF", "playerColoured": 1 },
	"ButtonAdvOptions": { "x": x - 121, "y": 292, "graphic": "IAM008.DEF", "playerColoured": 1 },
	"ButtonSysOptions": { "x": x - 89, "y": 292, "graphic": "IAM009.DEF", "playerColoured": 1 },
	"ButtonNextHero": { "x": x - 121, "y": 324, "graphic": "IAM000.DEF", "playerColoured": 1 },
	"ButtonEndTurn": { "x": x - 121, "y": 356, "graphic": "IAM001.DEF", "playerColoured": 1 }
}

print("\n" * 5)
print("{")
result = []
for k, v in elem.items():
	result.append("    \"%s\": %s" % (k, json.dumps(v)))
print(",\n".join(result))
print("},")
print("\n" * 5)
exit = input("press enter key to continue...")